// ==================================================
// FILE: api/crypto-enhanced.js
// Enhanced endpoint with full signal data for filtering
// ==================================================

export const config = {
  runtime: 'edge',
  maxDuration: 60, // Allow up to 60 seconds for this endpoint
};

// Import calculation functions (these are duplicated from backend for edge function)
const calculateRSI = (prices, period = 14) => {
  if (!prices || prices.length < period + 1) return null;
  
  const changes = [];
  for (let i = 1; i < prices.length; i++) {
    changes.push(prices[i] - prices[i - 1]);
  }
  
  if (changes.length < period) return null;
  
  const recentChanges = changes.slice(-period * 2);
  
  let avgGain = 0;
  let avgLoss = 0;
  
  for (let i = 0; i < period; i++) {
    const change = recentChanges[i] || 0;
    if (change > 0) {
      avgGain += change;
    } else {
      avgLoss += Math.abs(change);
    }
  }
  
  avgGain /= period;
  avgLoss /= period;
  
  for (let i = period; i < recentChanges.length; i++) {
    const change = recentChanges[i] || 0;
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;
    
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }
  
  if (avgLoss === 0) return 100;
  
  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));
  
  return Math.round(rsi * 10) / 10;
};

const calculateSMA = (prices, period) => {
  if (!prices || prices.length < period) return null;
  const slice = prices.slice(-period);
  const sum = slice.reduce((a, b) => a + b, 0);
  return sum / period;
};

const calculateBollingerBands = (prices, period = 20, stdDev = 2) => {
  if (!prices || prices.length < period) return null;
  
  const slice = prices.slice(-period);
  const sma = slice.reduce((a, b) => a + b, 0) / period;
  
  const squaredDiffs = slice.map(price => Math.pow(price - sma, 2));
  const variance = squaredDiffs.reduce((a, b) => a + b, 0) / period;
  const std = Math.sqrt(variance);
  
  return {
    upper: sma + (std * stdDev),
    middle: sma,
    lower: sma - (std * stdDev)
  };
};

const calculateVolumeRatio = (volumes, period = 20) => {
  if (!volumes || volumes.length < period + 1) return null;
  
  const currentVolume = volumes[volumes.length - 1];
  const avgVolume = calculateSMA(volumes.slice(0, -1), period);
  
  if (!avgVolume || avgVolume === 0) return null;
  return currentVolume / avgVolume;
};

// Helper to get Bybit symbol
const getBybitSymbol = (symbol) => {
  const normalized = symbol?.toUpperCase().trim()
    .replace(/USD$/, '')
    .replace(/USDT$/, '')
    .replace(/USDC$/, '');
  return `${normalized}USDT`;
};

// Helper to get OKX symbol
const getOKXSymbol = (symbol) => {
  const normalized = symbol?.toUpperCase().trim()
    .replace(/USD$/, '')
    .replace(/USDT$/, '')
    .replace(/USDC$/, '');
  return `${normalized}-USDT-SWAP`;
};

// Fetch Bybit data for a single token
const fetchBybitData = async (symbol) => {
  try {
    const bybitSymbol = getBybitSymbol(symbol);
    
    // Fetch klines and funding rate in parallel
    const [klinesRes, fundingRes] = await Promise.all([
      fetch(`https://api.bybit.com/v5/market/kline?category=linear&symbol=${bybitSymbol}&interval=60&limit=200`),
      fetch(`https://api.bybit.com/v5/market/tickers?category=linear&symbol=${bybitSymbol}`)
    ]);
    
    if (!klinesRes.ok) return null;
    
    const klinesData = await klinesRes.json();
    if (klinesData.retCode !== 0 || !klinesData.result?.list) return null;
    
    const klines = klinesData.result.list.reverse();
    const prices = klines.map(k => parseFloat(k[4]));
    const volumes = klines.map(k => parseFloat(k[5]));
    
    let fundingRate = null;
    if (fundingRes.ok) {
      const fundingData = await fundingRes.json();
      if (fundingData.retCode === 0 && fundingData.result?.list?.[0]) {
        fundingRate = parseFloat(fundingData.result.list[0].fundingRate);
      }
    }
    
    return { prices, volumes, fundingRate, source: 'bybit' };
  } catch (error) {
    return null;
  }
};

// Fetch OKX data for a single token
const fetchOKXData = async (symbol) => {
  try {
    const okxSymbol = getOKXSymbol(symbol);
    
    const [candlesRes, fundingRes] = await Promise.all([
      fetch(`https://www.okx.com/api/v5/market/candles?instId=${okxSymbol}&bar=1H&limit=200`),
      fetch(`https://www.okx.com/api/v5/public/funding-rate?instId=${okxSymbol}`)
    ]);
    
    if (!candlesRes.ok) return null;
    
    const candlesData = await candlesRes.json();
    if (candlesData.code !== '0' || !candlesData.data) return null;
    
    const candles = candlesData.data.reverse();
    const prices = candles.map(c => parseFloat(c[4]));
    const volumes = candles.map(c => parseFloat(c[6]));
    
    let fundingRate = null;
    if (fundingRes.ok) {
      const fundingData = await fundingRes.json();
      if (fundingData.code === '0' && fundingData.data?.[0]) {
        fundingRate = parseFloat(fundingData.data[0].fundingRate);
      }
    }
    
    return { prices, volumes, fundingRate, source: 'okx' };
  } catch (error) {
    return null;
  }
};

// Enhance a single token with signal data
const enhanceToken = async (token) => {
  // Try Bybit first
  let exchangeData = await fetchBybitData(token.symbol);
  
  // Try OKX if Bybit fails
  if (!exchangeData) {
    exchangeData = await fetchOKXData(token.symbol);
  }
  
  // If we got exchange data, calculate signals
  if (exchangeData && exchangeData.prices.length >= 50) {
    const sma50 = calculateSMA(exchangeData.prices, 50);
    const bb = calculateBollingerBands(exchangeData.prices, 20, 2);
    const volumeRatio = exchangeData.volumes.length > 20 
      ? calculateVolumeRatio(exchangeData.volumes, 20) 
      : null;
    
    return {
      ...token,
      // Signal flags for filtering
      signals: {
        rsiOversold: token.rsi !== null && token.rsi < 30,
        rsiExtreme: token.rsi !== null && token.rsi < 25,
        aboveSMA50: sma50 ? token.price > sma50 : null,
        belowBB: bb ? token.price < bb.lower : null,
        volumeSpike: volumeRatio ? volumeRatio > 1.5 : null,
        hasFunding: exchangeData.fundingRate !== null && exchangeData.fundingRate !== undefined,
        negativeFunding: exchangeData.fundingRate !== null && exchangeData.fundingRate < 0,
      },
      // Raw values for detail view
      sma50,
      bollingerBands: bb,
      volumeRatio,
      fundingRate: exchangeData.fundingRate,
      dataSource: exchangeData.source,
      enhanced: true,
    };
  }
  
  // Return basic token with signal flags based on available data
  return {
    ...token,
    signals: {
      rsiOversold: token.rsi !== null && token.rsi < 30,
      rsiExtreme: token.rsi !== null && token.rsi < 25,
      aboveSMA50: null,
      belowBB: null,
      volumeSpike: null,
      hasFunding: null,
      negativeFunding: null,
    },
    enhanced: false,
  };
};

// Chunk array helper
const chunk = (arr, size) => {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
};

// Smart categorization (same as main API)
const getCategoryFromMetadata = (id, name, symbol) => {
  const idLower = id.toLowerCase();
  const nameLower = name.toLowerCase();
  const symbolLower = symbol.toLowerCase();
  
  const layer1Ids = ['bitcoin', 'ethereum', 'solana', 'cardano', 'avalanche-2', 'polkadot', 
                     'polygon-ecosystem-token', 'matic-network', 'arbitrum', 'optimism',
                     'cosmos', 'near-protocol', 'aptos', 'sui', 'kaspa', 'tron', 'litecoin',
                     'stellar', 'algorand', 'fantom', 'hedera-hashgraph', 'internet-computer',
                     'the-open-network', 'stacks', 'injective-protocol', 'sei-network', 'celestia'];
  if (layer1Ids.includes(idLower) || nameLower.includes('network') || nameLower.includes('chain')) {
    return 'layer-1';
  }
  
  const memeKeywords = ['doge', 'shib', 'inu', 'pepe', 'floki', 'bonk', 'meme', 'wojak',
                        'shiba', 'baby', 'elon', 'cat', 'popcat', 'mog', 'turbo', 'brett',
                        'wif', 'bome', 'coq', 'myro', 'wen', 'neiro', 'dogs', 'ponke'];
  if (memeKeywords.some(keyword => idLower.includes(keyword) || nameLower.includes(keyword) || symbolLower.includes(keyword))) {
    return 'meme';
  }
  
  const defiIds = ['chainlink', 'uniswap', 'aave', 'maker', 'lido-dao', 'curve-dao-token',
                   'pancakeswap-token', 'compound-governance-token', 'synthetix-network-token',
                   'thorchain', 'the-graph', 'raydium', 'jupiter-exchange-solana', 'pendle',
                   '1inch', 'sushi', 'balancer', 'convex-finance', 'yearn-finance'];
  const defiKeywords = ['swap', 'dex', 'lending', 'defi', 'finance', 'protocol'];
  if (defiIds.includes(idLower) || defiKeywords.some(k => idLower.includes(k) || nameLower.includes(k))) {
    return 'defi';
  }
  
  const aiIds = ['render-token', 'fetch-ai', 'singularitynet', 'ocean-protocol', 'bittensor',
                 'worldcoin', 'akash-network', 'arkham', 'artificial-superintelligence-alliance'];
  const aiKeywords = ['ai', 'artificial', 'intelligence', 'neural', 'render', 'compute'];
  if (aiIds.includes(idLower) || aiKeywords.some(k => idLower.includes(k) || nameLower.includes(k))) {
    return 'ai';
  }
  
  const gamingIds = ['the-sandbox', 'decentraland', 'axie-infinity', 'gala', 'immutable-x',
                     'enjincoin', 'beam', 'echelon-prime', 'gala-games'];
  const gamingKeywords = ['game', 'gaming', 'meta', 'verse', 'land', 'sandbox', 'axie', 'play'];
  if (gamingIds.includes(idLower) || gamingKeywords.some(k => idLower.includes(k) || nameLower.includes(k))) {
    return 'gaming';
  }
  
  const exchangeIds = ['binancecoin', 'crypto-com-chain', 'okb', 'kucoin-shares', 'gate-token',
                       'ftx-token', 'huobi-token'];
  if (exchangeIds.includes(idLower) || idLower.includes('exchange')) {
    return 'exchange';
  }
  
  const stableIds = ['tether', 'usd-coin', 'dai', 'first-digital-usd', 'true-usd',
                     'paxos-standard', 'frax', 'tusd', 'usdd'];
  const stableKeywords = ['usd', 'dollar', 'stable'];
  if (stableIds.includes(idLower) || stableKeywords.some(k => symbolLower.includes(k))) {
    return 'stable';
  }
  
  return 'other';
};

export default async function handler(req) {
  const CG_API_KEY = process.env.COINGECKO_API_KEY;
  
  if (!CG_API_KEY) {
    return new Response(
      JSON.stringify({ error: 'COINGECKO_API_KEY not configured' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }

  try {
    console.log('🚀 Starting enhanced data fetch...');
    const startTime = Date.now();
    
    // Fetch base CoinGecko data (4 pages = 1000 tokens)
    const pages = [1, 2, 3, 4];
    const allData = [];
    
    for (const page of pages) {
      const cgRes = await fetch(
        'https://pro-api.coingecko.com/api/v3/coins/markets?' + new URLSearchParams({
          vs_currency: 'usd',
          order: 'market_cap_desc',
          per_page: '250',
          page: String(page),
          sparkline: 'true',
          price_change_percentage: '1h,24h,7d,30d',
        }),
        {
          headers: {
            'x-cg-pro-api-key': CG_API_KEY,
            'Accept': 'application/json',
          },
        }
      );
      
      if (!cgRes.ok) {
        throw new Error(`CoinGecko API error: ${cgRes.status}`);
      }
      
      const pageData = await cgRes.json();
      allData.push(...pageData);
    }
    
    // Deduplicate
    const seenIds = new Set();
    const dedupedData = allData.filter(coin => {
      if (seenIds.has(coin.id)) return false;
      seenIds.add(coin.id);
      return true;
    });
    
    console.log(`✅ Fetched ${dedupedData.length} tokens from CoinGecko`);
    
    const totalMcap = dedupedData.reduce((sum, c) => sum + (c.market_cap || 0), 0);

    // Process base token data
    const baseTokens = dedupedData.map((coin, index) => {
      const sparklineData = coin.sparkline_in_7d?.price || [];
      const rsi = calculateRSI(sparklineData, 14);
      
      let normalizedSparkline = [];
      if (sparklineData.length > 0) {
        const startPrice = sparklineData[0];
        normalizedSparkline = sparklineData.map(p => (p / startPrice) * 100);
      }
      
      const category = getCategoryFromMetadata(coin.id, coin.name, coin.symbol);
      
      return {
        id: coin.id,
        cgId: coin.id,
        symbol: coin.symbol?.toUpperCase(),
        name: coin.name,
        rank: coin.market_cap_rank || index + 1,
        price: coin.current_price,
        mcap: coin.market_cap,
        volume: coin.total_volume,
        change1h: coin.price_change_percentage_1h_in_currency,
        change24h: coin.price_change_percentage_24h_in_currency,
        change7d: coin.price_change_percentage_7d_in_currency,
        change30d: coin.price_change_percentage_30d_in_currency,
        supply: coin.circulating_supply,
        maxSupply: coin.max_supply,
        ath: coin.ath,
        athChange: coin.ath_change_percentage,
        athDate: coin.ath_date,
        atl: coin.atl,
        atlChange: coin.atl_change_percentage,
        atlDate: coin.atl_date,
        dominance: coin.market_cap ? (coin.market_cap / totalMcap) * 100 : 0,
        rsi: rsi,
        sparkline: normalizedSparkline,
        sparklineRaw: sparklineData,
        image: coin.image,
        category: category,
        volMcap: coin.market_cap ? (coin.total_volume / coin.market_cap) * 100 : 0,
      };
    });
    
    console.log(`🔄 Enhancing top 250 tokens with exchange data...`);
    
    // Enhance top 250 tokens with exchange data (in batches)
    const tokensToEnhance = baseTokens.slice(0, 250);
    const batches = chunk(tokensToEnhance, 25); // 25 tokens per batch
    const enhancedTokens = [];
    
    let batchNum = 0;
    for (const batch of batches) {
      batchNum++;
      console.log(`  Batch ${batchNum}/${batches.length}...`);
      
      const batchResults = await Promise.all(
        batch.map(token => enhanceToken(token))
      );
      
      enhancedTokens.push(...batchResults);
      
      // Small delay to respect rate limits
      if (batchNum < batches.length) {
        await new Promise(resolve => setTimeout(resolve, 50));
      }
    }
    
    // Remaining tokens without enhancement
    const remainingTokens = baseTokens.slice(250).map(token => ({
      ...token,
      signals: {
        rsiOversold: token.rsi !== null && token.rsi < 30,
        rsiExtreme: token.rsi !== null && token.rsi < 25,
        aboveSMA50: null,
        belowBB: null,
        volumeSpike: null,
        hasFunding: null,
        negativeFunding: null,
      },
      enhanced: false,
    }));
    
    const allTokens = [...enhancedTokens, ...remainingTokens];
    const enhancedCount = enhancedTokens.filter(t => t.enhanced).length;
    
    const endTime = Date.now();
    const duration = ((endTime - startTime) / 1000).toFixed(2);
    
    console.log(`✅ Enhanced ${enhancedCount}/${allTokens.length} tokens in ${duration}s`);
    
    return new Response(
      JSON.stringify({
        tokens: allTokens,
        timestamp: new Date().toISOString(),
        source: 'coingecko+exchanges',
        stats: {
          total: allTokens.length,
          enhanced: enhancedCount,
          withRSI: allTokens.filter(t => t.rsi !== null).length,
          duration: `${duration}s`,
        }
      }),
      { 
        status: 200, 
        headers: { 
          'Content-Type': 'application/json',
          'Cache-Control': 's-maxage=120, stale-while-revalidate=600', // Cache 2 min
          'Access-Control-Allow-Origin': '*',
        } 
      }
    );

  } catch (error) {
    console.error('Enhanced API Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
